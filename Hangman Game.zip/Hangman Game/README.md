# Semester Project

## Name: Emmanuel Sowah Ago

## Class: IT B

## Index number: UEB3213322

Peoject Description:

## Hangman Game

The hangman project game consists of guessing a secret word of a given length
by entering one letter at a time. The game ends if the user does not correctly
guess the word within the allotted number of guesses. The Hangman game will
utilize classes to store the hidden word and guesses a class containing member
methods used to track progress, and a class to represent the hangman figure. The
game logic will be written using a variety of features such as structs, switch
statements, and loops of C++ programming language.
Technologies Required: C++ programming language, Object Oriented
Programming (OOPS).
